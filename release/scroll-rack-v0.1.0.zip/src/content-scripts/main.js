(function(){"use strict";const Te=document.createElement("div");Te.id="echomtg-fast-inventory",document.body.appendChild(Te);const N=Te.attachShadow({mode:"closed"}),_e=document.createElement("link");_e.rel="stylesheet",_e.href=chrome.runtime.getURL("assets/content-light.css"),N.appendChild(_e);let le=[];const Ut={"Mythic Rare":"M",Rare:"R",Uncommon:"U",Common:"C"},j="login",O="cache",x="ready";function qt(){const e=document.createElement("div");e.innerHTML=`
    <!-- Collapsed tab -->
    <div class="overlay-tab" id="overlay-tab">
      <img src="${chrome.runtime.getURL("icons/icon16.png")}" alt="Scroll Rack" class="overlay-tab-icon">
      Scroll Rack
    </div>

    <!-- Expanded panel -->
    <div class="overlay-panel hidden" id="overlay-panel">
      <div class="overlay-header">
        <img src="${chrome.runtime.getURL("icons/icon48.png")}" alt="Scroll Rack" class="overlay-icon">
        <span class="overlay-title">Scroll Rack</span>
        <button class="collapse-btn" id="collapse-btn" title="Collapse (Ctrl+Shift+E)">−</button>
      </div>

      <div class="overlay-body">
        <!-- === Account accordion === -->
        <div class="accordion-section" id="acc-account">
          <div class="accordion-header" id="acc-account-hdr">
            <div class="accordion-header-left">
              <span class="accordion-chevron">▶</span>
              <span class="accordion-title">Account</span>
            </div>
            <span class="accordion-status" id="acc-account-status"></span>
          </div>
          <div class="accordion-body" id="acc-account-body">
            <!-- Login form (shown when logged out) -->
            <div class="login-form" id="login-form">
              <input class="login-input" id="login-email" type="email" placeholder="Email" autocomplete="email">
              <input class="login-input" id="login-password" type="password" placeholder="Password" autocomplete="current-password">
              <div class="login-error hidden" id="login-error"></div>
              <div class="login-row">
                <button class="btn btn-primary" id="login-btn">Login</button>
              </div>
            </div>
            <!-- Logged-in info (shown when logged in) -->
            <div class="logged-in-info hidden" id="logged-in-info">
              <span class="logged-in-user" id="logged-in-user"></span>
              <button class="btn btn-sm btn-danger" id="logout-btn">Logout</button>
            </div>
          </div>
        </div>

        <!-- === Set Cache accordion === -->
        <div class="accordion-section disabled" id="acc-cache">
          <div class="accordion-header" id="acc-cache-hdr">
            <div class="accordion-header-left">
              <span class="accordion-chevron">▶</span>
              <span class="accordion-title">Set Cache</span>
            </div>
            <span class="accordion-status" id="acc-cache-status"></span>
          </div>
          <div class="accordion-body" id="acc-cache-body">
            <div class="set-filter-row">
              <input class="set-filter-input" id="set-filter-input" type="text" placeholder="Filter sets...">
              <button class="btn btn-sm" id="refresh-sets-btn" title="Refresh set list from EchoMTG">↻</button>
            </div>
            <div class="set-list" id="set-list"></div>
            <div class="cache-actions" id="cache-actions">
              <button class="btn btn-primary btn-sm" id="cache-btn" disabled>Cache Selected (0)</button>
              <button class="btn btn-sm hidden" id="cache-cancel-btn">Cancel</button>
            </div>
            <div class="cache-progress hidden" id="cache-progress">
              <div class="cache-progress-label" id="cache-progress-label"></div>
              <div class="cache-progress-track">
                <div class="cache-progress-fill" id="cache-progress-fill"></div>
              </div>
            </div>
            <div id="cached-data-area">
              <div class="cached-summary" id="cache-summary"></div>
              <div class="cached-set-list" id="cached-set-list"></div>
              <div class="clear-all-row hidden" id="clear-all-area">
                <button class="btn btn-sm btn-danger" id="clear-all-btn">Clear All</button>
              </div>
            </div>
          </div>
        </div>

        <!-- === Add Cards accordion === -->
        <div class="accordion-section disabled" id="acc-add-cards">
          <div class="accordion-header" id="acc-add-cards-hdr">
            <div class="accordion-header-left">
              <span class="accordion-chevron">▶</span>
              <span class="accordion-title">Add Cards</span>
            </div>
            <span class="accordion-status" id="acc-add-cards-status"></span>
          </div>
          <div class="accordion-body" id="acc-add-cards-body">
            <div class="location-bar">
              <label>Loc</label>
              <input class="location-input" id="loc-input" type="text" placeholder="tag">
              <label>Pos</label>
              <input class="position-value" id="pos-input" type="number" min="1" value="1">
              <label>Div</label>
              <input class="divider-input" id="div-input" type="number" min="0" value="50"
                     title="Insert divider every N cards (0 = off)">
            </div>

            <div class="checkout-search-filters" id="add-card-filters">
              <div class="filter-multi" id="add-filter-version-wrap">
                <button class="filter-multi-btn" id="add-filter-version-btn">Version</button>
                <div class="filter-multi-menu hidden" id="add-filter-version-menu">
                  <label><input type="checkbox" value="regular"> Regular</label>
                  <label><input type="checkbox" value="foil"> Foil</label>
                  <label><input type="checkbox" value="Anime"> Anime</label>
                  <label><input type="checkbox" value="Borderless"> Borderless</label>
                  <label><input type="checkbox" value="Poster"> Poster</label>
                  <label><input type="checkbox" value="Etched"> Etched</label>
                  <label><input type="checkbox" value="Extended Art"> Extended Art</label>
                  <label><input type="checkbox" value="Galaxy Foil"> Galaxy Foil</label>
                  <label><input type="checkbox" value="Gilded Foil"> Gilded Foil</label>
                  <label><input type="checkbox" value="Retro Frame"> Retro</label>
                  <label><input type="checkbox" value="Showcase"> Showcase</label>
                  <label><input type="checkbox" value="Step-And-Compleat Foil"> Step-and-Compleat</label>
                </div>
              </div>
              <div class="filter-multi" id="add-filter-set-wrap">
                <button class="filter-multi-btn" id="add-filter-set-btn">Set</button>
                <div class="filter-multi-menu hidden" id="add-filter-set-menu"></div>
              </div>
              <div class="filter-multi" id="add-filter-lang-wrap">
                <button class="filter-multi-btn" id="add-filter-lang-btn">Language</button>
                <div class="filter-multi-menu hidden" id="add-filter-lang-menu">
                  <label><input type="checkbox" value="EN"> English</label>
                  <label><input type="checkbox" value="JA"> Japanese</label>
                  <label><input type="checkbox" value="ZHS"> Chinese (S)</label>
                  <label><input type="checkbox" value="ZHT"> Chinese (T)</label>
                  <label><input type="checkbox" value="FR"> French</label>
                  <label><input type="checkbox" value="DE"> German</label>
                  <label><input type="checkbox" value="IT"> Italian</label>
                  <label><input type="checkbox" value="KO"> Korean</label>
                  <label><input type="checkbox" value="PT"> Portuguese</label>
                  <label><input type="checkbox" value="RU"> Russian</label>
                  <label><input type="checkbox" value="ES"> Spanish</label>
                  <label><input type="checkbox" value="PH"> Phyrexian</label>
                </div>
              </div>
            </div>

            <div class="divider-alert hidden" id="divider-alert">
              <span class="divider-alert-icon">📋</span>
              <span class="divider-alert-text" id="divider-alert-text"></span>
            </div>

            <div class="search-container">
              <input class="search-input" id="search-input" type="text"
                     placeholder="Type card name to search...">
            </div>

            <div class="results-list hidden" id="results-list"></div>
          </div>
        </div>

        <!-- === Move accordion === -->
        <div class="accordion-section disabled" id="acc-checkout">
          <div class="accordion-header" id="acc-checkout-hdr">
            <div class="accordion-header-left">
              <span class="accordion-chevron">▶</span>
              <span class="accordion-title">Move</span>
            </div>
            <span class="accordion-status" id="acc-checkout-status"></span>
          </div>
          <div class="accordion-body" id="acc-checkout-body">
            <!-- Inventory import -->
            <div class="checkout-import">
              <div class="checkout-import-row">
                <label class="btn btn-sm" id="checkout-import-label">
                  Import CSV
                  <input type="file" accept=".csv" id="checkout-import-file" style="display:none">
                </label>
                <button class="btn btn-sm hidden" id="checkout-sync-notes-btn" title="Sync note IDs from EchoMTG">Sync Notes</button>
                <span class="checkout-import-status" id="checkout-import-status">No inventory loaded</span>
                <button class="btn btn-sm btn-danger hidden" id="checkout-clear-inv-btn">Clear</button>
              </div>
            </div>

            <!-- Search mode tabs -->
            <div class="checkout-tabs">
              <button class="tab-btn active" id="checkout-tab-name">By Name</button>
              <button class="tab-btn" id="checkout-tab-list">By List</button>
            </div>

            <!-- By Name mode -->
            <div id="checkout-mode-name">
              <div class="search-container">
                <input class="search-input" id="checkout-search-input" type="text"
                       placeholder="Search your inventory..." disabled>
              </div>
            </div>

            <!-- By List mode -->
            <div id="checkout-mode-list" class="hidden">
              <div class="checkout-list-load-row">
                <select class="option-select checkout-list-select" id="checkout-echo-list-select">
                  <option value="">Select a list...</option>
                </select>
                <button class="btn btn-sm" id="checkout-load-list-btn" disabled>Load List</button>
              </div>
            </div>

            <!-- Filters (multi-select dropdowns) -->
            <div class="checkout-search-filters">
              <div class="filter-multi" id="filter-version-wrap">
                <button class="filter-multi-btn" id="filter-version-btn">Version</button>
                <div class="filter-multi-menu hidden" id="filter-version-menu">
                  <label><input type="checkbox" value="regular"> Regular</label>
                  <label><input type="checkbox" value="foil"> Foil</label>
                  <label><input type="checkbox" value="Anime"> Anime</label>
                  <label><input type="checkbox" value="Borderless"> Borderless</label>
                  <label><input type="checkbox" value="Poster"> Poster</label>
                  <label><input type="checkbox" value="Etched"> Etched</label>
                  <label><input type="checkbox" value="Extended Art"> Extended Art</label>
                  <label><input type="checkbox" value="Galaxy Foil"> Galaxy Foil</label>
                  <label><input type="checkbox" value="Gilded Foil"> Gilded Foil</label>
                  <label><input type="checkbox" value="Retro Frame"> Retro</label>
                  <label><input type="checkbox" value="Showcase"> Showcase</label>
                  <label><input type="checkbox" value="Step-And-Compleat Foil"> Step-and-Compleat</label>
                </div>
              </div>
              <div class="filter-multi" id="filter-set-wrap">
                <button class="filter-multi-btn" id="filter-set-btn">Set</button>
                <div class="filter-multi-menu hidden" id="filter-set-menu"></div>
              </div>
              <div class="filter-multi" id="filter-lang-wrap">
                <button class="filter-multi-btn" id="filter-lang-btn">Language</button>
                <div class="filter-multi-menu hidden" id="filter-lang-menu">
                  <label><input type="checkbox" value="EN"> English</label>
                  <label><input type="checkbox" value="JA"> Japanese</label>
                  <label><input type="checkbox" value="PH"> Phyrexian</label>
                </div>
              </div>
            </div>

            <!-- Shared card results -->
            <div class="checkout-card-list" id="checkout-search-cards"></div>

            <!-- Location checkout -->
            <div class="checkout-location-row">
              <div class="checkout-location-select-row">
                <label>Location</label>
                <div class="location-combobox" id="checkout-location-combobox">
                  <input class="location-input" id="checkout-location-input" type="text"
                         placeholder="Type or select location..." autocomplete="off">
                  <div class="location-combobox-list hidden" id="checkout-location-list"></div>
                </div>
              </div>
              <div class="checkout-offset-row">
                <label>Starting offset</label>
                <input class="position-value" id="checkout-offset-input" type="number" min="1" value="1">
                <span class="checkout-offset-hint" id="checkout-offset-hint"></span>
              </div>
            </div>

            <!-- Move button -->
            <div class="checkout-actions">
              <button class="btn btn-primary btn-sm" id="checkout-search-btn" disabled>Move (0)</button>
            </div>
          </div>
        </div>

        <!-- === Retrieval Plans accordion === -->
        <div class="accordion-section disabled" id="acc-plans">
          <div class="accordion-header" id="acc-plans-hdr">
            <div class="accordion-header-left">
              <span class="accordion-chevron">▶</span>
              <span class="accordion-title">Retrieval Plans</span>
            </div>
            <span class="accordion-status" id="acc-plans-status"></span>
          </div>
          <div class="accordion-body" id="acc-plans-body">
            <!-- Plan list view -->
            <div id="plans-list-view">
              <div class="plans-list" id="plans-list"></div>
              <div class="plans-empty hidden" id="plans-empty">No retrieval plans.</div>
            </div>
            <!-- Plan detail view -->
            <div id="plans-detail-view" class="hidden">
              <div class="checkin-back-link" id="plans-back-btn">← Back to plans</div>
              <div class="plans-detail-header" id="plans-detail-header"></div>
              <div class="plans-detail-items" id="plans-detail-items"></div>
              <div class="plans-actions">
                <button class="btn btn-sm" id="plans-print-btn">Print</button>
                <button class="btn btn-sm btn-danger" id="plans-delete-btn">Delete Plan</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="status-bar">
        <span class="status-message info" id="status-msg">Ready</span>
        <span class="session-count">Session: <strong id="session-count">0</strong></span>
      </div>
    </div>
  `,N.appendChild(e)}qt();const n=e=>N.querySelector(e),Ne=n("#overlay-tab"),ze=n("#overlay-panel"),Yt=n("#collapse-btn"),re=n("#acc-account"),Kt=n("#acc-account-hdr"),V=n("#acc-account-status"),E=n("#acc-cache"),Wt=n("#acc-cache-hdr"),G=n("#acc-cache-status"),U=n("#acc-add-cards"),jt=n("#acc-add-cards-hdr");n("#acc-add-cards-status");const q=n("#acc-checkout"),zt=n("#acc-checkout-hdr"),$e=n("#acc-checkout-status"),Je=n("#login-form"),de=n("#login-email"),Qe=n("#login-password"),ue=n("#login-error"),z=n("#login-btn"),Ze=n("#logged-in-info"),Jt=n("#logged-in-user"),Qt=n("#logout-btn"),$=n("#set-filter-input"),J=n("#refresh-sets-btn"),Q=n("#set-list"),Me=n("#cache-btn"),Xe=n("#cache-actions"),Ae=n("#cache-cancel-btn"),he=n("#cache-progress"),pe=n("#cache-progress-label"),et=n("#cache-progress-fill"),tt=n("#cache-summary"),ve=n("#cached-set-list"),st=n("#clear-all-area"),Z=n("#clear-all-btn"),X=n("#loc-input"),M=n("#pos-input"),me=n("#div-input"),at=n("#add-filter-version-btn"),nt=n("#add-filter-version-menu"),Zt=n("#add-filter-version-wrap"),ct=n("#add-filter-set-btn"),fe=n("#add-filter-set-menu"),Xt=n("#add-filter-set-wrap"),it=n("#add-filter-lang-btn"),Ie=n("#add-filter-lang-menu"),es=n("#add-filter-lang-wrap"),ot=n("#divider-alert"),ts=n("#divider-alert-text"),u=n("#search-input"),y=n("#results-list"),o=n("#status-msg"),ss=n("#session-count"),lt=n("#checkout-import-file");n("#checkout-import-label");const A=n("#checkout-import-status"),ee=n("#checkout-clear-inv-btn"),k=n("#checkout-sync-notes-btn"),f=n("#checkout-search-input"),h=n("#checkout-search-cards"),Y=n("#checkout-search-btn"),He=n("#checkout-tab-name"),Pe=n("#checkout-tab-list"),rt=n("#checkout-mode-name"),dt=n("#checkout-mode-list"),b=n("#checkout-echo-list-select"),I=n("#checkout-load-list-btn"),ut=n("#filter-version-btn"),ht=n("#filter-version-menu"),as=n("#filter-version-wrap"),pt=n("#filter-set-btn"),be=n("#filter-set-menu"),ns=n("#filter-set-wrap"),vt=n("#filter-lang-btn"),mt=n("#filter-lang-menu"),cs=n("#filter-lang-wrap"),g=n("#checkout-location-input"),w=n("#checkout-location-list"),te=n("#checkout-offset-input"),se=n("#checkout-offset-hint"),H=n("#acc-plans"),is=n("#acc-plans-hdr"),Re=n("#acc-plans-status"),De=n("#plans-list-view"),Fe=n("#plans-list"),ft=n("#plans-empty"),Be=n("#plans-detail-view"),os=n("#plans-back-btn"),Oe=n("#plans-detail-header"),Ve=n("#plans-detail-items"),ls=n("#plans-print-btn"),ae=n("#plans-delete-btn");let Ge=!1,v=[],m=-1,ge=!1,bt=0,gt=null,P=!1,ne=!1,ye="name",ke=[],R=null,yt="NM",S=j,T=null,L=new Map,Ue=!1;function Le(e){e.classList.add("open")}function Ce(e){e.classList.remove("open")}function ce(e){e.classList.toggle("open")}function ie(e){e.classList.remove("disabled")}function D(e){e.classList.add("disabled")}Kt.addEventListener("click",()=>{ce(re)}),Wt.addEventListener("click",()=>{E.classList.contains("disabled")||ce(E)}),jt.addEventListener("click",()=>{U.classList.contains("disabled")||ce(U)}),zt.addEventListener("click",()=>{q.classList.contains("disabled")||(ce(q),q.classList.contains("open")&&It())}),is.addEventListener("click",()=>{H.classList.contains("disabled")||(ce(H),H.classList.contains("open")&&we())});function F(e){S=e,rs()}function rs(){switch(S){case j:Le(re),Ce(E),D(E),D(U),D(q),D(H),u.disabled=!0,V.textContent="",V.className="accordion-status",G.textContent="",G.className="accordion-status";break;case O:Ce(re),ie(E),Le(E),D(U),D(q),D(H),u.disabled=!0,V.textContent="✓ "+(T||"Logged in"),V.className="accordion-status complete",oe();break;case x:Ce(re),Ce(E),ie(E),ie(U),ie(q),ie(H),Le(U),u.disabled=!1,V.textContent="✓ "+(T||"Logged in"),V.className="accordion-status complete",oe();break}}function oe(){const e=L.size;if(e>0){const t=Array.from(L.values()).reduce((s,a)=>s+(a.card_count||0),0);G.textContent=`✓ ${e} set${e!==1?"s":""}, ${t.toLocaleString()} cards`,G.className="accordion-status complete"}else G.textContent="No sets cached",G.className="accordion-status"}function kt(){return P?ne?x:O:j}async function Lt(){Ge=!0,ze.classList.remove("hidden"),Ne.classList.add("hidden"),await ps(),S===x?u.focus():S===j&&de.focus()}function qe(){Ge=!1,ze.classList.add("hidden"),Ne.classList.remove("hidden")}function ds(){Ge?qe():Lt()}Ne.addEventListener("click",Lt),Yt.addEventListener("click",qe),document.addEventListener("keydown",e=>{e.ctrlKey&&e.shiftKey&&e.key==="E"&&(e.preventDefault(),ds())}),z.addEventListener("click",async()=>{const e=de.value.trim(),t=Qe.value;if(!e||!t)return;z.disabled=!0,z.textContent="Logging in...",ue.classList.add("hidden");const s=await chrome.runtime.sendMessage({type:"LOGIN",email:e,password:t});z.disabled=!1,z.textContent="Login",s!=null&&s.ok?(T=s.user||e,await chrome.storage.local.set({echoUser:T}),P=!0,Ye(),await K(),F(ne?x:O),_(),S===x&&u.focus()):(ue.textContent=(s==null?void 0:s.error)||"Login failed",ue.classList.remove("hidden"))}),Qt.addEventListener("click",async()=>{await chrome.runtime.sendMessage({type:"LOGOUT"}),await chrome.storage.local.remove("echoUser"),P=!1,T=null,Ct(),F(j),de.focus()});function Ye(){Je.classList.add("hidden"),Ze.classList.remove("hidden"),Jt.textContent=T||"Authenticated"}function Ct(){Je.classList.remove("hidden"),Ze.classList.add("hidden"),de.value="",Qe.value="",ue.classList.add("hidden")}function _(e=""){const t=e.toLowerCase();Q.innerHTML="";for(const s of le){if(t&&!s.name.toLowerCase().includes(t)&&!s.code.toLowerCase().includes(t))continue;const a=L.get(s.code),c=document.createElement("div");c.className="set-row",c.innerHTML=`
      <input type="checkbox" data-code="${s.code}">
      <span class="set-name">${d(s.name)}</span>
      <span class="set-code">${s.code}</span>
      ${a?`<span class="set-cached">${a.card_count} cards</span>`:'<span class="set-not-cached">—</span>'}
    `,Q.appendChild(c)}Et()}function xt(){return Array.from(Q.querySelectorAll('input[type="checkbox"]:checked')).map(e=>e.dataset.code)}function Et(){const e=xt().length;Me.textContent=`Cache Selected (${e})`,Me.disabled=e===0}Q.addEventListener("change",Et),$.addEventListener("input",()=>{_($.value)}),J.addEventListener("click",async()=>{var e;J.disabled=!0,J.textContent="...",o.textContent="Refreshing set list...",o.className="status-message pending";try{const t=await chrome.runtime.sendMessage({type:"REFRESH_KNOWN_SETS"});t!=null&&t.ok&&((e=t.sets)==null?void 0:e.length)>0?(le=t.sets,_($.value),o.textContent=`Loaded ${t.sets.length} sets`,o.className="status-message"):(o.textContent=`Refresh failed: ${(t==null?void 0:t.error)||"no sets returned"}`,o.className="status-message error")}catch(t){o.textContent=`Refresh error: ${t.message}`,o.className="status-message error"}J.disabled=!1,J.textContent="↻"}),Me.addEventListener("click",async()=>{var s;const e=xt();if(e.length===0)return;Ue=!1,Xe.classList.add("hidden"),he.classList.remove("hidden"),Ae.classList.remove("hidden");const t=[];for(let a=0;a<e.length&&!Ue;a++){const c=e[a];pe.textContent=`Caching ${c}... (${a+1}/${e.length})`,et.style.width=`${(a+.5)/e.length*100}%`;try{const i=await chrome.runtime.sendMessage({type:"CACHE_SETS",setCodes:[c]});if(i!=null&&i.ok){const l=(s=i.results)==null?void 0:s[0];l&&!l.ok&&t.push(`${c}: ${l.error}`)}else t.push(`${c}: ${(i==null?void 0:i.error)||"unknown error"}`)}catch(i){t.push(`${c}: ${i.message}`)}et.style.width=`${(a+1)/e.length*100}%`}he.classList.add("hidden"),Xe.classList.remove("hidden"),t.length>0&&(pe.textContent=`Errors: ${t.join("; ")}`,pe.style.color="#ef5350",he.classList.remove("hidden"),Ae.classList.add("hidden"),setTimeout(()=>{he.classList.add("hidden"),pe.style.color=""},5e3)),await K(),_($.value),oe(),ne&&S===O&&(F(x),u.focus())}),Ae.addEventListener("click",()=>{Ue=!0});async function K(){try{const e=await chrome.runtime.sendMessage({type:"GET_CACHED_SETS"});if(L.clear(),e!=null&&e.ok&&e.sets)for(const t of e.sets)L.set(t.set_code,t)}catch(e){console.warn("[overlay] refreshCachedSets error:",e)}ne=L.size>0,us(),ks()}function us(){const e=Array.from(L.values());if(ve.innerHTML="",e.length===0){tt.textContent="No sets cached",st.classList.add("hidden");return}const t=e.reduce((s,a)=>s+(a.card_count||0),0);tt.innerHTML=`<strong>${e.length}</strong> set${e.length!==1?"s":""} cached, <strong>${t.toLocaleString()}</strong> cards total`;for(const s of e){const a=document.createElement("div");a.className="cached-set-row";const c=s.active!==!1;a.innerHTML=`
      <div class="cached-set-info">
        <input type="checkbox" class="set-active-checkbox" 
               data-set-code="${s.set_code}" 
               ${c?"checked":""}>
        <span>${d(s.set_name)}</span>
        <span class="set-code">${s.set_code}</span>
        <span class="card-count">${s.card_count}</span>
      </div>
      <button class="btn btn-danger btn-sm" data-clear-code="${s.set_code}">Clear</button>
    `,ve.appendChild(a)}st.classList.remove("hidden")}ve.addEventListener("click",async e=>{const t=e.target.closest("[data-clear-code]");if(t){const s=t.dataset.clearCode;t.disabled=!0,t.textContent="...",await chrome.runtime.sendMessage({type:"CLEAR_SET",setCode:s}),await K(),_($.value),oe(),!ne&&S===x&&F(O);return}}),ve.addEventListener("change",async e=>{if(e.target.classList.contains("set-active-checkbox")){const t=e.target.dataset.setCode,s=e.target.checked;await chrome.runtime.sendMessage({type:"SET_SET_ACTIVE",setCode:t,active:s});const a=L.get(t);a&&(a.active=s)}}),Z.addEventListener("click",async()=>{Z.disabled=!0,Z.textContent="Clearing...",await chrome.runtime.sendMessage({type:"CLEAR_ALL"}),await K(),_($.value),oe(),Z.disabled=!1,Z.textContent="Clear All",S===x&&F(O)}),X.addEventListener("change",()=>{chrome.runtime.sendMessage({type:"SET_STATE",key:"locationTag",value:X.value})}),M.addEventListener("change",()=>{chrome.runtime.sendMessage({type:"SET_STATE",key:"position",value:Number(M.value)}),xe()}),me.addEventListener("change",()=>{chrome.runtime.sendMessage({type:"SET_STATE",key:"dividerEvery",value:Number(me.value)}),xe()});async function hs(){var e,t;try{const{echoToken:s}=await chrome.storage.local.get("echoToken");P=!!s,P&&(T=(await chrome.storage.local.get("echoUser")).echoUser||"Authenticated",Ye()),await K();const a=await chrome.runtime.sendMessage({type:"GET_STATE",keys:["locationTag","position","dividerEvery","defaultCondition"]});if(a!=null&&a.ok&&a.values){const c=a.values;c.locationTag!=null&&(X.value=c.locationTag),c.position!=null&&(M.value=c.position),c.dividerEvery!=null&&(me.value=c.dividerEvery),c.defaultCondition&&(yt=c.defaultCondition)}}catch(s){console.error("[overlay] Failed to load state:",s),o.textContent="Failed to connect to extension",o.className="status-message error"}try{const s=await chrome.runtime.sendMessage({type:"GET_KNOWN_SETS"});console.log("[overlay] GET_KNOWN_SETS result:",s==null?void 0:s.ok,"sets:",(e=s==null?void 0:s.sets)==null?void 0:e.length),s!=null&&s.ok&&((t=s.sets)==null?void 0:t.length)>0?le=s.sets:console.warn("[overlay] No sets returned from service worker")}catch(s){console.warn("[overlay] Failed to load known sets:",s)}_(),le.length===0&&(Q.innerHTML='<div class="set-row" style="color: #999;">No sets available. Check service worker console for errors.</div>');try{await chrome.runtime.sendMessage({type:"GET_RETRIEVAL_PLANS"})}catch{}F(kt()),xe()}async function ps(){try{const{echoToken:e}=await chrome.storage.local.get("echoToken");P=!!e,P?(T=(await chrome.storage.local.get("echoUser")).echoUser||"Authenticated",Ye()):Ct(),await K(),_($.value)}catch(e){console.warn("[overlay] refreshState error:",e)}F(kt())}function xe(){const e=Number(M.value)||0,t=Number(me.value)||0;t>0&&e>1&&(e-1)%t===0?(ts.innerHTML=`<strong>Insert a divider</strong> — ${e-1} cards added (every ${t})`,ot.classList.remove("hidden")):ot.classList.add("hidden")}u.addEventListener("input",()=>{const e=u.value.trim();clearTimeout(gt),gt=setTimeout(()=>wt(e),100)});async function wt(e){try{const t=await chrome.runtime.sendMessage({type:"GET_ACTIVE_SETS"}),s=await chrome.runtime.sendMessage({type:"SEARCH_CARDS",query:e,activeSets:t!=null&&t.ok?t.activeSets:[]});s!=null&&s.ok?(v=gs(s.cards||[]),m=v.length>0?0:-1,Ee(),v.length===0?(o.textContent="No matches",o.className="status-message info"):(o.textContent=`${v.length} result${v.length!==1?"s":""}`,o.className="status-message info")):(o.textContent=`Search error: ${(s==null?void 0:s.error)||"unknown"}`,o.className="status-message error")}catch{o.textContent="Search failed — service worker not responding",o.className="status-message error"}}function Ke(){v=[],m=-1,y.innerHTML="",y.classList.add("hidden")}function Ee(){if(v.length===0){y.innerHTML="",y.classList.add("hidden");return}y.classList.remove("hidden"),y.innerHTML=v.map((e,t)=>{const s=Ut[e.rarity]||"",a=(e.variant_tags||[]).map(i=>`<span class="${e.is_foil_variant&&i.toLowerCase().includes("foil")?"badge badge-foil":"badge badge-variant"}">${d(i)}</span>`).join("");return`
        <div class="result-item${t===m?" selected":""}" data-index="${t}">
          <div class="result-thumb">
            ${e.image_cropped?`<img src="${d(e.image_cropped)}" alt="">`:""}
          </div>
          <div class="result-info">
            <div class="result-name">${d(e.name)}</div>
            <div class="result-meta">
              ${a}
              <span>${d(e.set_code)} #${e.collectors_number}</span>
              ${s?`<span class="rarity-${s}">${s}</span>`:""}
            </div>
          </div>
        </div>
      `}).join("")}function d(e){const t=document.createElement("span");return t.textContent=e,t.innerHTML}y.addEventListener("click",e=>{const t=e.target.closest(".result-item");if(!t||ge)return;const s=Number(t.dataset.index);s>=0&&s<v.length&&(m=s,Tt())}),u.addEventListener("keydown",e=>{if(v.length===0){e.key==="Escape"&&(u.value?(u.value="",Ke()):qe(),e.preventDefault());return}switch(e.key){case"ArrowDown":e.preventDefault(),m=(m+1)%v.length,Ee(),St();break;case"ArrowUp":e.preventDefault(),m=(m-1+v.length)%v.length,Ee(),St();break;case"Enter":e.preventDefault(),m>=0&&Tt();break;case"Escape":e.preventDefault(),u.value="",Ke();break}});function St(){const e=y.querySelector(".selected");e&&e.scrollIntoView({block:"nearest"})}async function Tt(){if(ge||m<0||m>=v.length)return;ge=!0;const e=v[m],t=y.querySelector(".selected");if(t){t.classList.add("adding");const a=document.createElement("span");a.className="adding-label",a.textContent="Adding…",t.appendChild(a)}o.textContent="Adding to inventory…",o.className="status-message pending",u.disabled=!0;const s=await chrome.runtime.sendMessage({type:"ADD_CARD",emid:e.emid,foil:e.is_foil_variant?1:0,condition:yt,language:ys(),locationTag:X.value,position:Number(M.value)});if(ge=!1,u.disabled=!1,s!=null&&s.ok){bt++,ss.textContent=bt;const a=s.noteText||`${X.value}p${M.value}`;o.textContent=`✓ ${e.name} added → ${a}`,o.className="status-message",M.value=s.newPosition,xe(),u.value="",Ke(),u.focus()}else o.textContent=`✗ Failed to add — ${(s==null?void 0:s.error)||"unknown error"}`,o.className="status-message error",Ee(),u.focus()}function C(){const e=h.querySelectorAll('input[type="checkbox"]:checked').length;Y.textContent=`Move (${e})`,Y.disabled=e===0}h.addEventListener("change",C);function vs(e){const t=e.split(/\r?\n/);if(t.length<2)return[];const s=_t(t[0]),a=[];for(let c=1;c<t.length;c++){const i=t[c].trim();if(!i)continue;const l=_t(i),r={};for(let p=0;p<s.length;p++)r[s[p]]=l[p]||"";a.push(r)}return a}function _t(e){const t=[];let s="",a=!1;for(let c=0;c<e.length;c++){const i=e[c];a?i==='"'?c+1<e.length&&e[c+1]==='"'?(s+='"',c++):a=!1:s+=i:i==='"'?a=!0:i===","?(t.push(s),s=""):s+=i}return t.push(s),t}function ms(e){return{echo_inventory_id:Number(e.echo_inventory_id)||0,emid:Number(e.echoid)||0,name:e.Name||"",name_lower:(e.Name||"").toLowerCase(),set_code:(e["Set Code"]||"").toUpperCase(),set_name:e.Set||"",collectors_number:e["Collector Number"]||"",rarity:e.Rarity||"",condition:e.Condition||"NM",language:e.Language||"EN",foil:Number(e["Foil Qty"]||0)>0,note:e.note||"",acquired_price:parseFloat(e.Acquired)||0,date_acquired:e["Date Acquired"]||""}}lt.addEventListener("change",async e=>{const t=e.target.files[0];if(t){A.textContent="Importing...",f.disabled=!0;try{const s=await t.text(),c=vs(s).map(ms).filter(l=>l.echo_inventory_id>0),i=await chrome.runtime.sendMessage({type:"IMPORT_INVENTORY",records:c});i!=null&&i.ok?(A.textContent=`${i.count.toLocaleString()} cards loaded`,ee.classList.remove("hidden"),k.classList.remove("hidden"),f.disabled=!1,o.textContent=`Imported ${i.count.toLocaleString()} inventory cards`,o.className="status-message",$t(),Mt()):(A.textContent=`Import failed: ${i==null?void 0:i.error}`,o.textContent=`Import failed: ${i==null?void 0:i.error}`,o.className="status-message error")}catch(s){A.textContent="Import failed",o.textContent=`Import error: ${s.message}`,o.className="status-message error"}lt.value=""}}),ee.addEventListener("click",async()=>{await chrome.runtime.sendMessage({type:"CLEAR_INVENTORY"}),A.textContent="No inventory loaded",ee.classList.add("hidden"),k.classList.add("hidden"),f.disabled=!0,h.innerHTML="",C()}),k.addEventListener("click",async()=>{k.disabled=!0,k.textContent="Syncing...",o.textContent="Syncing note IDs from EchoMTG...",o.className="status-message pending";try{const e=await chrome.runtime.sendMessage({type:"SYNC_NOTE_IDS"});e!=null&&e.ok?(o.textContent=`Synced ${e.synced} note IDs (${e.remaining||0} remaining)`,o.className="status-message"):(o.textContent=`Sync failed: ${(e==null?void 0:e.error)||"unknown"}`,o.className="status-message error")}catch(e){o.textContent=`Sync error: ${e.message}`,o.className="status-message error"}k.disabled=!1,k.textContent="Sync Notes"}),He.addEventListener("click",()=>{ye="name",He.classList.add("active"),Pe.classList.remove("active"),rt.classList.remove("hidden"),dt.classList.add("hidden"),h.innerHTML="",C()}),Pe.addEventListener("click",async()=>{ye="list",Pe.classList.add("active"),He.classList.remove("active"),dt.classList.remove("hidden"),rt.classList.add("hidden"),h.innerHTML="",C();try{b.innerHTML='<option value="">Loading lists...</option>';const e=await chrome.runtime.sendMessage({type:"GET_ECHO_LISTS"});if(b.innerHTML='<option value="">Select a list...</option>',e!=null&&e.ok&&e.lists.length>0)for(const t of e.lists){const s=document.createElement("option");s.value=t.id,s.textContent=t.name,b.appendChild(s)}else e!=null&&e.error?b.innerHTML=`<option value="">Error: ${e.error}</option>`:b.innerHTML='<option value="">No lists found</option>'}catch(e){console.warn("[overlay] Failed to load echo lists:",e),b.innerHTML='<option value="">Failed to load lists</option>'}}),b.addEventListener("change",()=>{I.disabled=!b.value}),I.addEventListener("click",async()=>{const e=b.value;if(e){I.disabled=!0,I.textContent="Loading...",h.innerHTML='<div class="checkout-card-item">Loading list...</div>';try{const t=await chrome.runtime.sendMessage({type:"GET_ECHO_LIST",listId:e});if(t!=null&&t.ok&&t.emids.length>0){const s=Nt(),a=await chrome.runtime.sendMessage({type:"SEARCH_INVENTORY_BY_EMIDS",emids:t.emids,filters:s});a!=null&&a.ok&&(a.cards.length===0?h.innerHTML='<div class="checkout-card-item">No matching inventory cards</div>':Bt(h,a.cards),C())}else h.innerHTML='<div class="checkout-card-item">No cards in list or list not found</div>'}catch{h.innerHTML='<div class="checkout-card-item">Failed to load list</div>'}I.disabled=!1,I.textContent="Load List"}});function W(e,t,s,a){e.addEventListener("click",c=>{c.stopPropagation(),N.querySelectorAll(".filter-multi-menu").forEach(i=>{i!==t&&i.classList.add("hidden")}),t.classList.toggle("hidden")}),t.addEventListener("change",()=>{fs(e,t,e.dataset.label||e.textContent),a&&a()}),t.addEventListener("click",c=>c.stopPropagation())}function fs(e,t,s){const a=t.querySelectorAll('input[type="checkbox"]:checked');a.length===0?(e.textContent=s,e.classList.remove("filter-active")):a.length===1?(e.textContent=a[0].parentElement.textContent.trim(),e.classList.add("filter-active")):(e.textContent=`${s} (${a.length})`,e.classList.add("filter-active"))}ut.dataset.label="Version",pt.dataset.label="Set",vt.dataset.label="Language",W(ut,ht,as,je),W(pt,be,ns,je),W(vt,mt,cs,je),at.dataset.label="Version",ct.dataset.label="Set",it.dataset.label="Language",W(at,nt,Zt,We),W(ct,fe,Xt,We),W(it,Ie,es,We),N.addEventListener("click",()=>{N.querySelectorAll(".filter-multi-menu").forEach(e=>e.classList.add("hidden"))});function B(e){return Array.from(e.querySelectorAll('input[type="checkbox"]:checked')).map(t=>t.value)}function Nt(){const e={},t=B(ht);t.length>0&&(e.versions=t);const s=B(be);s.length>0&&(e.set_codes=s);const a=B(mt);return a.length>0&&(e.languages=a),e}function bs(){const e={},t=B(nt);t.length>0&&(e.versions=t);const s=B(fe);s.length>0&&(e.set_codes=s);const a=B(Ie);return a.length>0&&(e.languages=a),e}function gs(e){const t=bs();return!t.versions&&!t.set_codes?e:e.filter(s=>{if(t.versions){const a=(s.variant_tags||[]).map(i=>i.toLowerCase());if(!t.versions.some(i=>i==="regular"?!s.is_foil_variant&&a.length===0:i==="foil"?s.is_foil_variant:a.some(l=>l.toLowerCase()===i.toLowerCase())))return!1}return!(t.set_codes&&!t.set_codes.includes(s.set_code))})}function ys(){const e=B(Ie);return e.length>0?e[0]:"EN"}function We(){const e=u.value.trim();e&&wt(e)}function ks(){fe.innerHTML="";for(const[e,t]of L){if(t.active===!1)continue;const s=document.createElement("label");s.innerHTML=`<input type="checkbox" value="${d(e)}"> ${d(t.set_name)} (${d(e)})`,fe.appendChild(s)}}async function $t(){try{const e=await chrome.runtime.sendMessage({type:"GET_INVENTORY_SETS"});if(e!=null&&e.ok){be.innerHTML="";for(const t of e.sets){const s=document.createElement("label");s.innerHTML=`<input type="checkbox" value="${d(t.set_code)}"> ${d(t.set_name)} (${d(t.set_code)})`,be.appendChild(s)}}}catch(e){console.warn("[overlay] populateCheckoutFilters error:",e)}}function je(){if(ye==="name"){const e=f.value.trim();e&&Pt(e)}else ye==="list"&&b.value&&I.click()}async function Mt(){try{const e=await chrome.runtime.sendMessage({type:"GET_INVENTORY_LOCATIONS"});e!=null&&e.ok&&(ke=e.locations,Ls())}catch(e){console.warn("[overlay] populateCheckoutLocations error:",e)}}function Ls(){const e=g.value.trim();if(!e)return;const t=ke.find(s=>s.tag.toLowerCase()===e.toLowerCase());t&&(te.value=t.maxPosition+1,se.textContent=`Next position after ${t.maxPosition} existing`)}function At(e){const t=e.toLowerCase(),s=ke.filter(a=>!t||a.tag.toLowerCase().includes(t));if(s.length===0){w.innerHTML="",w.classList.add("hidden");return}w.innerHTML=s.map(a=>`<div class="location-combobox-item" data-tag="${d(a.tag)}" data-max="${a.maxPosition}">${d(a.tag)} <span class="location-combobox-count">(${a.maxPosition} cards)</span></div>`).join(""),w.classList.remove("hidden")}g.addEventListener("focus",()=>{At(g.value)}),g.addEventListener("blur",()=>{setTimeout(()=>{w.classList.add("hidden")},150)}),g.addEventListener("input",()=>{At(g.value);const e=ke.find(t=>t.tag.toLowerCase()===g.value.trim().toLowerCase());e?(te.value=e.maxPosition+1,se.textContent=`Next position after ${e.maxPosition} existing`):g.value.trim()?(te.value=1,se.textContent="New location starts at position 1"):se.textContent=""}),w.addEventListener("click",e=>{const t=e.target.closest(".location-combobox-item");if(!t)return;const s=t.dataset.tag,a=Number(t.dataset.max)||0;g.value=s,te.value=a+1,se.textContent=`Next position after ${a} existing`,w.classList.add("hidden")}),N.addEventListener("click",e=>{e.target.closest("#checkout-location-combobox")||w.classList.add("hidden")});async function It(){try{const e=await chrome.runtime.sendMessage({type:"GET_INVENTORY_STATS"});e!=null&&e.ok&&e.count>0?(A.textContent=`${e.count.toLocaleString()} cards loaded`,ee.classList.remove("hidden"),k.classList.remove("hidden"),f.disabled=!1,await $t(),await Mt()):(A.textContent="No inventory loaded",ee.classList.add("hidden"),k.classList.add("hidden"),f.disabled=!0);const t=await chrome.runtime.sendMessage({type:"GET_CHECKOUT_GROUPS"});if(t!=null&&t.ok){const s=t.groups.reduce((a,c)=>a+c.count,0);s>0?($e.textContent=`${s} card${s!==1?"s":""} out`,$e.className="accordion-status"):$e.textContent=""}}catch(e){console.warn("[overlay] loadCheckoutData error:",e)}}let Ht=null;f.addEventListener("input",()=>{clearTimeout(Ht);const e=f.value.trim();if(!e){h.innerHTML="",C();return}Ht=setTimeout(()=>Pt(e),300)});async function Pt(e){if(f.value.trim()===e)try{h.innerHTML='<div class="checkout-card-item">Searching...</div>';const s=Nt(),a=await chrome.runtime.sendMessage({type:"SEARCH_INVENTORY_FILTERED",query:e,filters:s});a!=null&&a.ok?(a.cards.length===0?h.innerHTML='<div class="checkout-card-item">No results</div>':Bt(h,a.cards),C()):h.innerHTML=`<div class="checkout-card-item">Error: ${(a==null?void 0:a.error)||"unknown"}</div>`}catch(s){console.warn("[overlay] checkoutSearch error:",s),h.innerHTML='<div class="checkout-card-item">Search failed</div>'}}function Rt(e){return e?e.replace(/\s*\([^)]*\)\s*/g,"").trim().toLowerCase():""}const Dt=["plains","island","swamp","mountain","forest"];function Cs(e){return[...e].sort((t,s)=>{const a=Rt(t.name),c=Rt(s.name),i=Dt.indexOf(a),l=Dt.indexOf(c),r=i!==-1,p=l!==-1;if(r&&!p)return 1;if(!r&&p)return-1;if(r&&p){if(i!==l)return i-l;const Gt=(t.set_code||"").localeCompare(s.set_code||"");return Gt!==0?Gt:Ft(t.collectors_number,s.collectors_number)}const Se=a.localeCompare(c);if(Se!==0)return Se;const Vt=(t.set_code||"").localeCompare(s.set_code||"");return Vt!==0?Vt:Ft(t.collectors_number,s.collectors_number)})}function Ft(e,t){const s=parseInt(e,10),a=parseInt(t,10);return!isNaN(s)&&!isNaN(a)&&s!==a?s-a:(e||"").localeCompare(t||"")}function Bt(e,t){const s=Cs(t);e.innerHTML=s.map(a=>`
    <div class="checkout-card-item" data-inventory-id="${a.echo_inventory_id}" data-emid="${a.emid}">
      <input type="checkbox" class="checkout-cb">
      <div class="checkout-card-info">
        <div class="checkout-card-name">${d(a.name)}${a.foil?' <span class="badge badge-foil">Foil</span>':""}</div>
        <div class="checkout-card-meta">${d(a.set_code)} #${a.collectors_number}${a.language&&a.language!=="EN"?` · ${d(a.language)}`:""}${a.note?` · ${d(a.note)}`:""}</div>
      </div>
    </div>
  `).join("")}Y.addEventListener("click",async()=>{const e=h.querySelectorAll('input[type="checkbox"]:checked');if(e.length===0)return;const t=Array.from(e).map(c=>Number(c.closest(".checkout-card-item").dataset.inventoryId)),s=g.value.trim(),a=Number(te.value)||1;if(!s){o.textContent="Please select or enter a location",o.className="status-message error";return}Y.disabled=!0,Y.textContent="Moving...";try{const c=await chrome.runtime.sendMessage({type:"CHECKOUT_CARDS",inventoryIds:t,targetLocation:s,targetOffset:a});c!=null&&c.ok?(o.textContent=`Moved ${t.length} card${t.length!==1?"s":""}`,o.className="status-message",h.innerHTML="",f.value="",C(),await It(),c.planId&&(Le(H),Ot(c.planId))):(o.textContent=`Move failed: ${(c==null?void 0:c.error)||"unknown"}`,o.className="status-message error")}catch{o.textContent="Move failed",o.className="status-message error"}Y.disabled=!1,C()});async function we(){try{const e=await chrome.runtime.sendMessage({type:"GET_RETRIEVAL_PLANS"});if(!(e!=null&&e.ok))return;const t=e.plans;if(t.length===0){Fe.innerHTML="",ft.classList.remove("hidden"),Re.textContent="";return}ft.classList.add("hidden"),Re.textContent=`${t.length} plan${t.length!==1?"s":""}`,Re.className="accordion-status",Fe.innerHTML=t.map(s=>{const a=s.items?s.items.length:0,c=s.items?s.items.filter(i=>i.checked).length:0;return`
        <div class="checkin-group-card" data-plan-id="${s.id}">
          <div class="checkin-group-info">
            <div class="checkin-group-name">${d(s.title)}</div>
            <div class="checkin-group-meta">${a} card${a!==1?"s":""} · ${c} retrieved</div>
          </div>
          <button class="btn btn-sm checkin-view-btn">View</button>
          <button class="btn btn-sm btn-danger plan-delete-btn">Delete</button>
        </div>
      `}).join("")}catch(e){console.warn("[overlay] loadRetrievalPlans error:",e)}}Fe.addEventListener("click",async e=>{const t=e.target.closest("[data-plan-id]");if(!t)return;const s=Number(t.dataset.planId);if(e.target.closest(".checkin-view-btn")){await Ot(s);return}const a=e.target.closest(".plan-delete-btn");if(a){a.disabled=!0,a.textContent="...";try{const c=await chrome.runtime.sendMessage({type:"DELETE_RETRIEVAL_PLAN",id:s});c!=null&&c.ok?(o.textContent="Plan deleted",o.className="status-message",we()):(o.textContent=`Delete failed: ${(c==null?void 0:c.error)||"unknown"}`,o.className="status-message error",a.disabled=!1,a.textContent="Delete")}catch(c){o.textContent=`Delete error: ${c.message}`,o.className="status-message error",a.disabled=!1,a.textContent="Delete"}}});async function Ot(e){R=e,De.classList.add("hidden"),Be.classList.remove("hidden");try{const t=await chrome.runtime.sendMessage({type:"GET_RETRIEVAL_PLAN",id:e});if(!(t!=null&&t.ok)||!t.plan){Oe.textContent="Plan not found",Ve.innerHTML="";return}const s=t.plan;Oe.innerHTML=`<strong>${d(s.title)}</strong>`;const a=new Map;(s.items||[]).forEach((i,l)=>{const r=i.current_location||"Unknown location";a.has(r)||a.set(r,[]),a.get(r).push({...i,_index:l})});let c="";for(const[i,l]of a){c+='<div class="plan-location-group">',c+=`<div class="plan-location-header">${d(i)}</div>`;for(const r of l){const p=r.checked?" plan-item-done":"";c+=`
          <div class="plan-item${p}" data-plan-id="${e}" data-item-index="${r._index}">
            <input type="checkbox" class="plan-item-cb" ${r.checked?"checked":""}>
            <span class="plan-item-text">p${r.current_position||"?"} — ${d(r.card_name)} (${d(r.set_code)} #${r.collectors_number||""})</span>
          </div>
        `}c+="</div>"}Ve.innerHTML=c}catch(t){console.warn("[overlay] showPlanDetail error:",t),Oe.textContent="Error loading plan"}}Ve.addEventListener("change",async e=>{const t=e.target.closest(".plan-item-cb");if(!t)return;const s=t.closest(".plan-item"),a=Number(s.dataset.planId),c=Number(s.dataset.itemIndex),i=t.checked;i?s.classList.add("plan-item-done"):s.classList.remove("plan-item-done");try{await chrome.runtime.sendMessage({type:"UPDATE_PLAN_ITEM",planId:a,itemIndex:c,checked:i})}catch(l){console.warn("[overlay] updatePlanItem error:",l)}}),os.addEventListener("click",()=>{Be.classList.add("hidden"),De.classList.remove("hidden"),R=null,we()}),ls.addEventListener("click",async()=>{if(R)try{const e=await chrome.runtime.sendMessage({type:"GET_RETRIEVAL_PLAN",id:R});if(!(e!=null&&e.ok)||!e.plan)return;const t=e.plan,s=new Map;(t.items||[]).forEach(l=>{const r=l.current_location||"Unknown";s.has(r)||s.set(r,[]),s.get(r).push(l)});let a="";for(const[l,r]of s){a+=`<h3>${l}</h3><ul>`;for(const p of r){const Se=p.checked?"checked":"";a+=`<li><input type="checkbox" ${Se} disabled> p${p.current_position||"?"} — ${p.card_name} (${p.set_code} #${p.collectors_number||""})</li>`}a+="</ul>"}const c=`<!DOCTYPE html>
<html><head><title>Retrieval Plan: ${t.title}</title>
<style>
  body { font-family: sans-serif; max-width: 700px; margin: 20px auto; }
  h2 { border-bottom: 2px solid #333; padding-bottom: 4px; }
  h3 { color: #555; margin-top: 16px; margin-bottom: 4px; }
  ul { list-style: none; padding-left: 0; }
  li { padding: 4px 0; font-size: 14px; }
  input[type="checkbox"] { margin-right: 8px; }
  @media print { body { font-size: 12px; } }
</style></head>
<body>
  <h2>Retrieval Plan: ${t.title}</h2>
  ${a}
</body></html>`,i=window.open("","_blank");i.document.write(c),i.document.close(),i.print()}catch(e){console.warn("[overlay] print plan error:",e)}}),ae.addEventListener("click",async()=>{if(R){ae.disabled=!0,ae.textContent="Deleting...";try{const e=await chrome.runtime.sendMessage({type:"DELETE_RETRIEVAL_PLAN",id:R});e!=null&&e.ok?(o.textContent="Plan deleted",o.className="status-message",Be.classList.add("hidden"),De.classList.remove("hidden"),R=null,we()):(o.textContent=`Delete failed: ${(e==null?void 0:e.error)||"unknown"}`,o.className="status-message error")}catch(e){o.textContent=`Delete error: ${e.message}`,o.className="status-message error"}ae.disabled=!1,ae.textContent="Delete Plan"}}),hs()})();
